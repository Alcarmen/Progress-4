from flask import Flask, render_template,request,url_for,redirect,session,flash
from dbhelper import *

app = Flask(__name__)
app.secret_key= '696969BRANDON696969'

app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response
	
@app.route("/logout")
def logout()->None:
	if "user" in session:
		session.pop("user")
		flash("Logged Out")
	return render_template("login.html",title="Welcome to Brandon's Book Store")

@app.route("/")
def main()->None:
	return render_template("indexs.html",title="Welcome to Brandon's Book Store")


@app.route('/home')
def home():
    if "user" in session:
        if session['user'][1] == 'admin':
            return render_template("Home.html")
        
        return redirect("/User")
    else:
        flash("Error")
        return render_template("login.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        """
        if email == 'admin' and password == 'admin':
            # Redirect admin to home page
            session['email'] = email
            return redirect('/home')
        """

        # Fetch user details based on email and password from the database
        user = getrecords('customers', email=email, password=password)

        if user and user['active'] == 1:  # Check if user exists and is active
            session['user'] = (user['c_email'],user['role'],user['c_id'])

            if user['role'] == 'admin':
                return redirect('/home')
            
            return redirect('/User')
        else:
            flash('Invalid credentials or inactive account')
            return render_template('login.html')

    return render_template('login.html')

@app.route('/User')
def User():
    if "user" in session:
            if(session['user'][1] == 'customer'):
                items = getall("items")
 
                return render_template("User_end.html", items=items)
            
            return redirect("/home")
    else:
         flash("Error")
         return render_template("login.html")

@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        # Get form data
        c_name, c_email, c_address, password = dict(request.form).values()

        # Check if any field is empty
        if not all([c_name, c_email, c_address, password]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('register'))

        existing_customer = getrecord('customers', c_email=c_email)
        if existing_customer:
            flash('Email already exists. Please use a different email.')
            return redirect(url_for('register'))  

        addrecord('customers', c_name=c_name, c_email=c_email, c_address=c_address, password=password)
        flash('Registered successfully!')
        return redirect(url_for('login'))

    return render_template("register.html", title="Register Page")

    
@app.route('/Custom',methods=['GET','POST'])
def Custom():
    data = getall("customers")
    head:list= ['C_id','C_name','c_email','c_address', 'password', 'role','actions']       
      
    return render_template("index.html", student=data, header=head)
    
@app.route('/Item')
def Item():
    it= getall("items")
    head:list= ['id','ISBN','Title','Author','Genre', 'Price','I_Type','qty', 'Action']

    return render_template("itemindex.html",item=it, header=head)
 
@app.route('/create', methods=['GET','POST'])
def create():
    if request.method == 'POST':
        c_name,c_email,c_address=dict(request.form).values()

        if not all([c_name, c_email, c_address]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('create'))

        existing_customer = getrecord('customers', c_email=c_email)
        if existing_customer:
            flash('Email already exists. Please use a different email.')
            return redirect(url_for('create'))  
        else:
            flash('Customer has been added succesfully!')
            addrecord('customers',c_name=c_name, c_email=c_email, c_address=c_address)
            return redirect(url_for('Custom'))
    return render_template("Create.html")

@app.route('/createitem', methods=['GET', 'POST'])
def createitem():
    if request.method == 'POST':
        ISBN, title, author, genre, price, i_type,qty = dict(request.form).values()

        if not all([ISBN, title, author, genre, price, i_type,qty]):
            flash('All fields are required. Please fill in all the information.')
            return redirect(url_for('createitem'))
        
        existing_item = getrecord('items', ISBN=ISBN)
        
        if existing_item:
            flash('Error: ISBN already exists.')
            return redirect(url_for('createitem'))
        else:
            flash('Item has been added succesfully!')
            addrecord('items', ISBN=ISBN, title=title, author=author, genre=genre, price=price, i_type=i_type,qty=qty)
            return redirect(url_for('Item'))
            
    return render_template("Item-Create.html")

@app.route('/update/<c_id>', methods=['GET','POST'])
def update(c_id):
    if request.method == 'POST':
        c_name,c_email,c_address=dict(request.form).values()
        updaterecord('customers',c_id=c_id,c_name=c_name, c_email=c_email, c_address=c_address)
        return redirect(url_for('Custom'))
       
    customer = None
    customers = getrecord('customers',c_id=c_id)
    if len(customers) > 0:
        customer = customers[0]
    return render_template("Update.html",customer=customer)

@app.route('/delete_cust/<c_id>',methods=['GET'])
def delete_cust(c_id):
    if request.method == 'GET':
        deleterecord('customers',c_id=c_id)
        return redirect(url_for("Custom"))

#-------ITEMS---------
@app.route('/update_item/<i_id>', methods=['GET', 'POST'])
def update_item(i_id):
    item = None
    items = getrecord('items', i_id=i_id)
    
    if len(items) > 0:
        item = items[0]
    
    if request.method == 'POST':
        form_data = request.form
        
        ISBN = form_data.get('ISBN')
        title = form_data.get('title')
        author = form_data.get('author')
        genre = form_data.get('genre')
        price = form_data.get('price')  # Retrieve price from form data
        i_type = form_data.get('i_type')
        qty = form_data.get('qty')
        
        if int(qty) < 0:
            flash("Quantity cannot be lesser than 0!")
            return redirect(url_for('Item'))
        
        # Convert qty to 'Out of Stock' if it's 0
        if int(qty) == 0:
            qty = 'Out of Stock'
        
        # Check if price is a valid number or not
        try:
            price = float(price)
        except ValueError:
            flash("Price should be a valid number!")
            return redirect(url_for('Item'))
        
        # Update record with the new values
        updaterecord('items', i_id=i_id, ISBN=ISBN, title=title, author=author, genre=genre, price=price, i_type=i_type, qty=qty)
        
        return redirect(url_for('Item'))
       
    return render_template("Item-Update.html", item=item)

@app.route('/delete_item/<i_id>',methods=['GET'])
def delete_item(i_id):
    if request.method == 'GET':
        deleterecord('items',i_id=i_id)
        return redirect(url_for("Item"))
        
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        search_query = request.form.get('search_query')
        print("Search Query:", search_query)  # Check if the query is captured correctly

        results = searchrecord('customers', search_query)
        print("Results:", results)  # Check the results obtained

        if not results:
            flash("No result found!")
            return render_template("Searched.html", error_message="No result found!")  # Redirect to a route displaying the flashed message

        return render_template("Searched.html", results=results)

    return redirect(url_for("Custom"))



@app.route('/search_item', methods=['GET', 'POST'])
def search_item():
    if request.method == 'POST':
        item_searched = request.form.get('item_searched')
        print("Search Query:", item_searched)  # Check if the query is captured correctly

        output = itemrecord('items', item_searched)
        print("Results:", output)  # Check the results obtained

        if not output:
            flash("No result found!")
            return render_template("Item-Search.html", error_message="No result found!")  # Create a NoResults.html template

        return render_template("Item-Search.html", output=output)

    return redirect(url_for("Item"))

def get_count(table, column='*'):
    db = db_connect()
    cursor = db.cursor()
    cursor.execute(f"SELECT COUNT({column}) FROM {table}")
    count = cursor.fetchone()[0]
    db.close()
    return count

@app.route('/display')
def display_column_count():
    table_name = 'customers'  # Replace with your actual table name
    column_count = get_count(table_name)
    return render_template('count.html', column_count=column_count)

def get_user_id(c_id):
    sql = """
    SELECT user_id 
    FROM customers 
    WHERE c_id = %s AND active = 1
    """
    result = getProcess(sql, (c_id,))
    return result[0]['user_id'] if (result and result[0].get('user_id')) else None

def get_cart_items_with_c_id(user_id):
    sql = """
    SELECT cart.*, customers.c_id
    FROM cart
    JOIN customers ON cart.user_id = customers.user_id
    WHERE cart.user_id = %s
    """
    result = getProcess(sql, (user_id,))
    return result if result else []

@app.route('/add_to_cart/<isbn>', methods=['POST'])
def add_to_cart(isbn):
    if 'user' in session:
        # Assuming you have a function to get item details based on ISBN
        item = get_item_details(isbn)

        if item:
            # Get the quantity from the form data
            quantity = int(request.form.get('qty', 1))

            # Check if the requested quantity is available in stock
            if item.get('qty', 0) >= quantity > 0:
                # Initialize the cart in the session if not already present
                session.setdefault('cart', [])
                cart = session['cart']

                # Add the item to the cart with quantity
                cart.append({
                    'ISBN': item['ISBN'],
                    'title': item['title'],
                    'price': item['price'],
                    'quantity': quantity,
                })

                # Update the available stock in the items table
                new_qty = item['qty'] - quantity
                update_item_qty(item['ISBN'], new_qty)

                flash(f'{quantity} x {item["title"]} added to cart!')
                session['added_item'] = {'item': item, 'quantity': quantity}  # Save the added item and quantity in session
                return redirect('/view_cart')  # Redirect to cart view
            else:
                flash('Error: Out of stock or invalid quantity')
                return redirect('/User')
        else:
            flash('Item not found!')
    else:
        flash('Please log in to add items to your cart.')
    return render_template('login.html')


@app.route('/view_cart')
def view_cart():
    cart = session.get('cart', [])
    added_item = session.pop('added_item', None)
    return render_template('cart.html', cart=cart, added_item=added_item)

@app.route('/Cart')
def Cart():
    c_id = session.get('c_id')  # Retrieve c_id from the session or use your logic to get it
    user_id = get_user_id(c_id)
    
    if user_id:
        cart_items = get_cart_items_with_c_id(user_id)  # Fetch cart items for the user

        if cart_items:
            return render_template('cart.html', cart_items=cart_items)
        else:
            flash('Cart is empty!')
    else:
        flash('User not found or not logged in!')

    return redirect('/user')



        
if __name__=='__main__':
    
    app.run(debug=True)