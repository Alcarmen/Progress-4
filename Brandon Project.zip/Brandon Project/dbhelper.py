"""
	Python Database helper
"""
from mysql.connector import connect

def db_connect()->object:
    return connect(
        host="localhost",
        user="root",
        password="",
        database="customer"
    )
    
def doProcess(sql: str, params: tuple = ()) -> bool:
    db: object = db_connect()
    cursor: object = db.cursor()
    cursor.execute(sql, params)
    db.commit()
    return True if cursor.rowcount > 0 else False

def getProcess(sql: str, params: tuple = ()) -> list:
    db = db_connect()
    cursor = db.cursor(dictionary=True)
    cursor.execute(sql, params)
    return cursor.fetchall()

def getrecords(table: str, email: str, password: str) -> dict:
    sql = f"SELECT * FROM `{table}` WHERE `c_email` = '{email}' AND `password` = '{password}' AND `active` = 1"
    user = getProcess(sql)

    if user:
        return user[0]
    else:
        return None
def get_item_details(isbn: str) -> dict:
    sql = f"SELECT * FROM `items` WHERE `ISBN` = '{isbn}' AND `active` = 1"
    item = getProcess(sql)

    if item:
        return item[0]
    else:
        return None
    
def update_item_qty(isbn: str, new_qty: int) -> None:
    sql = "UPDATE items SET qty = %s WHERE ISBN = %s"
    params = (new_qty, isbn)
    doProcess(sql, params)

def getall(table:str)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1"
    return getProcess(sql)

def getrecord(table:str,**kwargs)->list:
    params:list = list(kwargs.items())
    flds:list = list(params[0])
    sql:str = f"SELECT * FROM `{table}` WHERE `{flds[0]}`='{flds[1]}'"
    return getProcess(sql)
    
def addrecord(table:str,**kwargs)->bool:
    flds:list = list(kwargs.keys())
    vals:list = list(kwargs.values())
    fld:str = "`,`".join(flds)
    val:str = "','".join(vals)
    sql:str = f"INSERT INTO `{table}`(`{fld}`) values('{val}')"
    print(sql)
    return doProcess(sql)

def addrecords(table, **kwargs):
    columns = ', '.join(kwargs.keys())
    values_template = ', '.join(['%s'] * len(kwargs))
    values = tuple(kwargs.values())

    sql = f"INSERT INTO {table} ({columns}) VALUES ({values_template})"
    return doProcess(sql, values)

    
def updaterecord(table:str,**kwargs)->bool:
    flds:list = list(kwargs.keys())
    vals:list = list(kwargs.values())
    fld:list = []
    for i in range(1,len(flds)):
        fld.append(f"`{flds[i]}`='{vals[i]}'")
    params:str = ",".join(fld)
    sql:str = f"UPDATE `{table}` SET {params} WHERE `{flds[0]}`='{vals[0]}'"
    print(sql)
    return doProcess(sql)
    
def deleterecord(table:str,**kwargs)->bool:
    params:list = list(kwargs.items())
    flds:list = list(params[0])
    sql:str = f"UPDATE `{table}` SET active = 0 WHERE `{flds[0]}`='{flds[1]}'"
    return doProcess(sql)
    
def searchrecord(table:str,search_term)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1 AND (c_name LIKE '%{search_term}%' OR c_email LIKE '%{search_term}%' OR c_address LIKE '%{search_term}%')"
    return getProcess(sql)
def itemrecord(table:str,search_item)->list:
    sql:str = f"SELECT * FROM `{table}` WHERE active = 1 AND (ISBN LIKE '%{search_item}%' OR title LIKE '%{search_item}%' OR author LIKE '%{search_item}%' OR genre LIKE '%{search_item}%' OR price LIKE '%{search_item}%' OR i_type LIKE '%{search_item}%')"
    return getProcess(sql)

def getrecords(table:str, email:str, password:str) -> dict:
    # Fetch user details based on email and password from the database
    sql = f"SELECT * FROM `{table}` WHERE `c_email` = '{email}' AND `password` = '{password}' AND `active` = 1"
    user = getProcess(sql)
    
    if user:
        return user[0]  # Return the first user found
    else:
        return None


