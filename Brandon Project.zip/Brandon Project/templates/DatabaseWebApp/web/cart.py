from flask import Blueprint, render_template, request, flash, redirect,  url_for, Flask, session
import mysql.connector

cart = Blueprint('cart', __name__)

db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "webapp",
}


