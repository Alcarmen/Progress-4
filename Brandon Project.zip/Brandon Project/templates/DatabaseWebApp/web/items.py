from flask import Blueprint, render_template, request, flash, redirect,  url_for, Flask, jsonify
import mysql.connector

items = Blueprint('items', __name__)

db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "webapp",
}

    
def get_item_data():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM items where i_active = 0"
    cursor.execute(show_query)
    data = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return data

@items.route('/showitems', methods=['GET','POST'])
def showitems():
    data = get_item_data()
    return render_template("itemdetails.html", data=data)

@items.route('/finditem', methods=['GET','POST'])
def findcustomer():
    search_id = request.args.get('id', default='', type=str)
    data = find(search_id)
    return render_template("itemdetails.html", data=data, search_id=search_id)

def find(search_id):
    id = request.form.get('id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM items WHERE i_title LIKE %s AND i_active = 0"
    search_id = f'%{search_id}%'
    cursor.execute(show_query, (search_id,))
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    return data

@items.route('/additems', methods=['GET','POST'])
def additems():
    if request.method == 'POST':
        isbn = request.form.get('ISBN')
        title = request.form.get('title')
        author = request.form.get('author')
        genre = request.form.get('genre')
        type = request.form.get('type')
        price = request.form.get('price')

        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        insert_query = "INSERT INTO items(i_isbn, i_title, i_author, i_genre, i_type, i_price) VALUES (%s,%s,%s,%s,%s,%s)"
        cursor.execute(insert_query, (isbn, title, author, genre, type, price))
        connection.commit()
        cursor.close()
        connection.close()
        flash('Item Details Added Successfuly', category='success')

    return render_template('/additems.html', bool = True)


@items.route('/deleteitems', methods=['GET','POST'])
def deleteitems():
    ok:bool = False
    if request.method == 'POST':
        id = request.form.get('id')
        if len(id) < 1:
            flash('Enter Name Properly', category='error')
        else:
            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor()
            del_query = "DELETE FROM items WHERE i_id = %s OR i_isbn = %s"
            cursor.execute(del_query, (id,id))
            connection.commit()
            cursor.close()
            connection.close()
            flash('Deleted Successfully', category='success')

            #flash('Enter Correct or Existing Name', category='error')

    return render_template("delitems.html", bool = True)


@items.route('/updateitems', methods=['GET','POST'])
def updateitem():

    id = request.form.get('id')
    
    if request.method == 'POST':
        input_text = " "
        if "button1" in request.form:
            if findID(id):
                flash('Item Found', category='success')
                
            else:
                flash('Item not Found', category='error')
                #return redirect("updateitem.html")

        else:        
            isbn = request.form.get('ISBN')
            title = request.form.get('title')
            author = request.form.get('author')
            genre = request.form.get('genre')
            type = request.form.get('type')
            price = request.form.get('price')

            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor()
            update_query = "UPDATE items SET i_isbn = %s, i_title = %s, i_author = %s, i_genre = %s, i_type = %s, i_price = %s WHERE i_id = %s"
            cursor.execute(update_query, (isbn, title, author, genre, type, price, id))
            connection.commit()
            cursor.close()
            connection.close()
            flash('Customer Updated Successfully', category='success')

    return render_template("updateitem.html", bool = True, input_text = id)


def findID(i_id):
    if request.method == 'POST':
        id = request.form.get('id')
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute("SELECT 1 FROM items WHERE i_id = %s", (i_id,))
        exists = cursor.fetchone() is not None
        connection.commit()
        cursor.close()
        connection.close()
    return exists

@items.route('/addmodalitem', methods=['POST'])
def addmodalitem():
    isbn = request.form['ISBN']
    title = request.form['title']
    author = request.form['author']
    genre = request.form['genre']
    type = request.form['type']
    price = request.form['price']
    stock = request.form['stock']
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    insert_query = "INSERT INTO items(i_isbn, i_title, i_author, i_genre, i_type, i_price, i_stocks) VALUES (%s,%s,%s,%s,%s,%s,%s)"
    cursor.execute(insert_query, (isbn, title, author, genre, type, price, stock))
    connection.commit()
    cursor.close()
    flash('Item Added', category='success')
    return redirect(url_for('items.showitems'))


@items.route('/deletemodalitem/<int:i_id>')
def deletemodalitem(i_id):
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute("UPDATE items SET i_active = 1 WHERE i_id = %s", (i_id,))
    connection.commit()
    cursor.close()
    flash('Item Deleted', category='success')
    return redirect(url_for('items.showitems'))

@items.route('/updatemodalitem/<int:i_id>', methods=['POST'])
def updatemodalitem(i_id):
    isbn = request.form['ISBN']
    title = request.form['title']
    author = request.form['author']
    genre = request.form['genre']
    type = request.form['type']
    price = request.form['price']
    stock = request.form['stock']
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    update_query = "UPDATE items SET i_isbn = %s, i_title = %s, i_author = %s, i_genre = %s, i_type = %s, i_price = %s, i_stocks = %s WHERE i_id = %s"
    cursor.execute(update_query, (isbn, title, author, genre, type, price, stock, i_id))
    connection.commit()
    cursor.close()
    flash('Item Updated', category='success')
    return redirect(url_for('items.showitems'))