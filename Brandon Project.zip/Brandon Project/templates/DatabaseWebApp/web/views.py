import dataclasses
from flask import Blueprint, render_template, request, flash, redirect,  url_for, Flask
import mysql.connector

db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "webapp",
}

views = Blueprint('views', __name__)

def get_data():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM customer WHERE c_active = 0"
    cursor.execute(show_query)
    data = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return data

@views.route('/showcustomer', methods=['GET','POST'])
def showcustomer():
    data = get_data()
    return render_template("customerdetails.html", data=data)

@views.route('/findcustomer', methods=['GET','POST'])
def findcustomer():
    search_id = request.args.get('id', default='', type=str)
    data = find(search_id)
    return render_template("customerdetails.html", data=data, search_id=search_id)

def find(search_id):
    id = request.form.get('id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM customer WHERE c_name LIKE %s AND c_active = 0"
    search_id = f'%{search_id}%'
    cursor.execute(show_query, (search_id,))
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    return data

@views.route('/addmodal', methods=['POST'])
def addmodal():
    name = request.form['name']
    email = request.form['email']
    address = request.form['address']
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    insert_query = "INSERT INTO customer(c_name, c_email, c_address) VALUES (%s,%s,%s)"
    cursor.execute(insert_query, (name, email, address))
    connection.commit()
    cursor.close()
    flash('Customer Added', category='success')
    return redirect(url_for('views.showcustomer'))


@views.route('/deletemodal/<int:c_id>')
def deletemodal(c_id):
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute("UPDATE customer SET c_active = 1 WHERE c_id = %s", (c_id,))
    connection.commit()
    cursor.close()
    flash('Customer Deleted', category='success')
    return redirect(url_for('views.showcustomer'))

@views.route('/updatemodal/<int:c_id>', methods=['POST'])
def updatemodal(c_id):
    name = request.form['name']
    email = request.form['email']
    address = request.form['address']
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    update_query = "UPDATE customer SET c_name = %s, c_email = %s, c_address = %s WHERE c_id = %s"
    cursor.execute(update_query, (name, email, address, c_id))
    connection.commit()
    cursor.close()
    flash('Customer Updated', category='success')
    return redirect(url_for('views.showcustomer'))