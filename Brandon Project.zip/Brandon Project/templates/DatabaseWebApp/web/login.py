from flask import Blueprint, render_template, request, flash, redirect,  url_for, Flask, session
import mysql.connector
from datetime import datetime

login = Blueprint('login', __name__)

db_config = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "webapp",
}

@login.route('/', methods=['GET','POST'])
def home():
    return render_template("home.html")

@login.route('/login', methods=['GET','POST'])
def user_login():
    username = request.form['email']
    password = request.form['password']

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    # Check if the username and password match for user
    query = "SELECT c_id FROM customer WHERE c_email = %s AND c_password = %s AND c_role = 'user'"
    cursor.execute(query, (username, password))
    user = cursor.fetchone()

    # Check if the username and password match for admin
    query = "SELECT c_id FROM customer WHERE c_email = %s AND c_password = %s AND c_role = 'admin'"
    cursor.execute(query, (username, password))
    admin = cursor.fetchone()

    if user:
        id = user[0]
        session['logged_in'] = True
        session['username'] = username
        session['c_id'] = id
        cursor.close()
        connection.close()
        #flash(id, category='success')
        return redirect(url_for('login.user_products'))
    elif admin:
        id = admin[0]
        session['admin_logged_in'] = True
        session['admin_username'] = username
        session['c_id'] = id
        cursor.close()
        connection.close()
        #flash(id, category='success')
        return redirect(url_for("views.showcustomer"))
    else:   
        return flash('Invalid username or password', category='error')

# Route to logout regular users
@login.route('/logout')
def user_logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    session.pop('admin_logged_in', None)
    session.pop('admin_username', None)
    session.pop('c_id', None)
    return redirect('/')   

def get_item_data():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM items where i_active = 0 AND i_stocks <> 0"
    cursor.execute(show_query)
    data = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return data

@login.route('/products')
def user_products():
    data = get_item_data()
    return render_template("products.html", data=data)

@login.route('/findproduct', methods=['GET','POST'])
def find_product():
    search_id = request.args.get('id', default='', type=str)
    data = find(search_id)  
    return render_template("products.html", data=data, search_id=search_id)

def find(search_id):
    id = request.form.get('id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT * FROM items WHERE i_title LIKE %s AND i_active = 0"
    search_id = f'%{search_id}%'
    cursor.execute(show_query, (search_id,))
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    return data

@login.route('/addcart', methods=['POST'])
def add_cart():
    title = request.form.get('title')
    qty = request.form.get('qty')
    c_id = session.get('c_id')
    stock = session.get('stock')
    cursor = None
    connection = None

    if c_id:
        try:
            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor()

            query_2 = "SELECT i_id, i_stocks FROM items WHERE i_title = %s"
            cursor.execute(query_2, (title,))
            item_data = cursor.fetchone()

            if item_data is not None:
                i_id, i_stock = item_data
                if int(qty) <= i_stock:  # Check if requested quantity is available in stock
                    insert_cart = "INSERT INTO cartitem (c_id, i_id, cart_qty) VALUES (%s, %s, %s)"
                    cursor.execute(insert_cart, (c_id, i_id, qty,))

                    update_stock = "UPDATE items SET i_stocks = i_stocks - %s WHERE i_id = %s"
                    cursor.execute(update_stock, (qty, i_id))

                    connection.commit()  # Commit changes to the database
                    flash("Successfully Added to Cart", category='success')

                                        # Pass i_id to checkout route
                    return redirect(url_for('login.user_products', i_id=i_id))
                else:
                    flash("Requested quantity exceeds available stock", category='error')
            else:
                flash("Item not found", category='error')

        except mysql.connector.Error as err:
            flash(f"Error: {err}", category='error')
            if connection:
                connection.rollback()

        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

    return redirect(url_for('login.user_products'))



@login.route('/register', methods=['GET','POST'])
def register_user():
    name = request.form['name']
    password = request.form['password']
    email = request.form['email']
    address = request.form['address']

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    insert_query = "INSERT INTO customer(c_name, c_password, c_email, c_address, c_role) VALUES (%s,%s,%s,%s,'user')"
    cursor.execute(insert_query, (name, password, email, address))
    connection.commit()
    cursor.close()
    flash('Customer Added', category='success')
    return redirect(url_for('login.home'))

@login.route('/cart', methods=['GET','POST'])
def user_cart():
    data = get_cart_data()
    return render_template("cart.html", data=data)

def get_cart_data():
    c_id = session.get('c_id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    show_query = "SELECT items.i_title, items.i_type, items.i_price, cartitem.cart_qty, (items.i_price * cartitem.cart_qty) AS total_amount FROM items INNER JOIN cartitem ON items.i_id = cartitem.i_id WHERE cartitem.c_id = %s and cartitem.ci_active = 0"
    cursor.execute(show_query, (c_id,))
    data = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return data

@login.route('/deleteCart/<string:i_title>', methods=['GET','POST'])
def del_cart(i_title):
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    delete_query = "DELETE cartitem FROM cartitem INNER JOIN items ON items.i_id = cartitem.i_id WHERE items.i_title = %s"
    cursor.execute(delete_query, (i_title,))    
    connection.commit()
    cursor.close()
    connection.close()
    flash('Item Deleted', category='success')
    return redirect(url_for('login.user_cart'))

@login.route('/orders', methods=['GET','POST'])
def user_order():
    orders = get_order_data()
    return render_template("orders.html", orders=orders)

def get_order_data():
    c_id = session.get('c_id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    select_query = """
        SELECT orders.o_id, customer.c_name, orders.o_date, customer.c_address
        FROM orders
        INNER JOIN customer ON orders.c_id = customer.c_id
        WHERE orders.c_id = %s
        ORDER BY orders.o_date DESC
    """    
    cursor.execute(select_query, (c_id,))
    orders = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return orders


@login.route('/checkout', methods=['GET','POST'])
def display_orders():
    c_id = session.get('c_id')
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    if c_id:
        try:
            get_cart_query = "SELECT i_id, cart_qty FROM cartitem WHERE c_id = %s AND ci_active = 0"
            cursor.execute(get_cart_query, (c_id,))
            cart_items = cursor.fetchall()

            if cart_items:
                current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                for item in cart_items:
                    i_id, qty = item
                    insert_order_query = "INSERT INTO orders (o_date, c_id, i_id) VALUES (%s, %s, %s)"
                    cursor.execute(insert_order_query, (current_timestamp, c_id, i_id))

                    update_stock_query = "UPDATE items SET i_stocks = i_stocks - %s WHERE i_id = %s"
                    cursor.execute(update_stock_query, (qty, i_id))

                update_cart_query = "UPDATE cartitem SET ci_active = 1 WHERE c_id = %s"
                cursor.execute(update_cart_query, (c_id,))

                
                connection.commit()
                flash('Items Ordered', category='success')
            else:
                flash('No items in the cart to checkout', category='error')

        except mysql.connector.Error as err:
            flash(f"Error: {err}", category='error')
            connection.rollback()

    cursor.close()
    connection.close()

    return redirect(url_for("login.user_order"))

@login.route('/addorder', methods=['GET','POST'])
def user_check_out():
    c_id = session.get('c_id')
    current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    insert_query = "INSERT INTO orders (o_date, c_id) VALUES (%s, %s)"
    cursor.execute(insert_query, (current_timestamp, c_id)) 
    connection.commit()
    cursor.close()
    connection.close()
    flash('Items Ordered', category='success')

    return display_orders()

@login.route('/showorders', methods=['GET','POST'])
def show_orders():
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    select_query = """
        SELECT customer.c_name, items.i_title, cartitem.cart_qty, 
               (items.i_price * cartitem.cart_qty) AS total_price, 
               customer.c_address, orders.o_date
        FROM customer
        LEFT JOIN cartitem ON customer.c_id = cartitem.c_id
        LEFT JOIN items ON cartitem.i_id = items.i_id
        LEFT JOIN orders ON customer.c_id = orders.c_id WHERE ci_active = 1
    """

    cursor.execute(select_query)
    order_details = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template('showorders.html', order_details=order_details)



